''' Buraya mesaj göndermek istediğin kişiyi ve mesajını girmelisin.'''

target  = 'kime'    # kime gönderilmeli 
message = 'ne mesajı'   # mesajın 


auto_send = True     # Otomatik mesaj gönderimi  

# Eğer True ise otomatik gönderir.
# False ise mesajı yazar ve bırakır, göndermez.