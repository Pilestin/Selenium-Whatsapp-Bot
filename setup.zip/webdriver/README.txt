1. Burada chromedriver.exe dosyası bulunduğundan emin ol.

2. Ayrıca Chrome sürümünün 110.0... olduğundan emin olun.

3. Eğer farklı bir sürüm kullanıyorsanız  : (https://chromedriver.chromium.org/downloads)  bu adresten
kendi sürümünüz için olan driver'ı indirip bu klasöre atın. (Eskisi ile yer değiştirin)